# @construct/authority-manifest

This package owns the canonical Construct authority manifest types and pure
resolution helpers.

Current host-authored sections:

- `scope`: project-wide read universe and package script permissions
- `surfaces`: product areas that define read-only host context and additive
  generated-artifact write roots
- `operations`: product behaviors, split into resources and actions

For Managed Variants, the resolved authority must also make the
surface-to-operation relationship explicit. Discovering an operation anywhere
in the repository does not grant every surface permission to invoke it.

Gatekeeper discovers project metadata and calls this package's resolver to
produce the concrete manifest-lock-style authority document.

## Current Shape

Hosts do not author the full resolved manifest directly. They author small SDK
markers:

- `construct.scope.ts` through `defineConstructScope`
- React surfaces through `<Surface />`
- Next route operations through `defineRouteOperations`

Gatekeeper enriches those markers with discovered routes, entrypoints, files,
runtime metadata, and operation lists.

Resolution is scope-first: a surface never creates global authority. Discovered
host files remain readable only when covered by `scope.read.allow` and not
blocked by `scope.read.deny`; only the surface additive root becomes
`read-write`. Out-of-scope, denied, and shared surface context produces resolver
findings instead of expanding authority.

## Still Needed

- Validation findings for duplicate ids and malformed declarations.
- Stronger canonical hashing.
- Persisted surface-to-operation grants and runtime invocation projection.
- Approval/audience receipt linkage for immutable Managed Variant versions.
- Future policy sections for imports, network, dependencies, secrets, artifacts,
  and runtime loading.
