# @construct/sdk

`@construct/sdk` is the host-facing authoring package. It lets an application
declare the UI boundary Construct may replace, describe the host operations a
variant may invoke, and resolve an approved runtime artifact without exposing
target credentials to the browser.

The recommended Next.js integration uses:

- `Surface` from `@construct/sdk/react` to mark and mount a replaceable UI
  boundary.
- `ConstructNextProvider` from `@construct/sdk/next/client` to bind host-owned
  resources and actions and resolve the document's immutable selector.
- `createConstructNextRuntimeServer` from `@construct/sdk/next/server` to make
  the authenticated, server-side Platform API request.
- `constructRuntimeHeadersFromEnv` from `@construct/sdk/next/server` to allow
  the configured immutable asset origin in the host Content Security Policy.
- `captureConstructRuntimeSelection` from `@construct/sdk/next/client` when the
  host wants to capture the selector explicitly during client instrumentation.
- `defineRouteOperations` from `@construct/sdk/next` to describe host-owned
  Next route operations.

`defineConstructScope` and `defineConstructOperations` remain available from
`@construct/sdk` for repository-level authority declarations. Security
semantics live in `@construct/authority-manifest`; Gatekeeper compiles and
validates them as a service.

## Declare the surface boundary

`Surface` must wrap only the part of the host UI that Construct may replace.
Persistent page chrome, navigation, titles, and other host-owned UI should stay
outside it.

```tsx
// src/app/page.tsx
import { Surface } from "@construct/sdk/react";

export default function Home() {
  return (
    <main>
      <header>
        <h1>Todo Runtime Check</h1>
        <p>This masthead always belongs to the host.</p>
      </header>

      <Surface
        className="todoSurface"
        id="todos.main"
        title="Todo workspace"
        description="Helps individuals organize and complete their current work."
        audience="Individual contributors"
        loadingFallback={<TodoSurfaceSkeleton />}
        useCases={["Plan current work", "Track completion"]}
      >
        <TodoApp />
      </Surface>
    </main>
  );
}
```

The SDK always renders a stable root element for the `Surface`, whether it is
showing the host fallback, a loading fallback, or a managed variant.
`className` is applied to that root. Gatekeeper scans the literal metadata in
host source, so keep `id`, `title`, and the optional descriptive fields directly
on `Surface`.

Construct sandbox frames may append
`?construct-inspect=surface-boundaries`. In a frame, that opt-in draws
Construct-owned clay inspection chrome one pixel outside the stable root and
labels it with the surface title. The overlay is mounted under `document.body`
and follows the root without changing its layout, inherited styles, or
containing block. The same query parameter does not draw the guide on a
top-level host page.

## Configure a Next.js host

### 1. Bind host-owned capabilities

The host owns every resource and action implementation. The Next provider owns
selector capture and the browser-to-host resolver request.

```tsx
// src/app/construct-provider.tsx
"use client";

import {
  ConstructNextProvider,
  type ConstructNextProviderProps,
} from "@construct/sdk/next/client";
import type { ConstructJsonValue } from "@construct/sdk/react";
import type { ReactNode } from "react";

const resourceHandlers: NonNullable<
  ConstructNextProviderProps["resourceHandlers"]
> = {
  "todos.list": async () => {
    const response = await fetch("/api/todos");
    if (!response.ok) throw new Error("Failed to load todos.");
    return (await response.json()) as ConstructJsonValue;
  },
};

const actionHandlers: NonNullable<
  ConstructNextProviderProps["actionHandlers"]
> = {
  "todos.create": async (input) => {
    const response = await fetch("/api/todos", {
      body: JSON.stringify(input),
      headers: { "content-type": "application/json" },
      method: "POST",
    });
    if (!response.ok) throw new Error("Failed to create a todo.");
    return (await response.json()) as ConstructJsonValue;
  },
};

export function TodoConstructProvider({ children }: { children: ReactNode }) {
  return (
    <ConstructNextProvider
      actionHandlers={actionHandlers}
      actionInvalidations={{ "todos.create": ["todos.list"] }}
      resourceHandlers={resourceHandlers}
    >
      {children}
    </ConstructNextProvider>
  );
}
```

The provider's default resolver path is
`/api/construct/runtime-artifacts/resolve`. `resolvePath` may change that
host-local path. Hosts should not put a Platform API URL, target ID, or target
secret in this client component.

Every capability used by an artifact must have an explicit host handler. A
capability ID does not imply an HTTP method, route, authentication policy, or
response shape. A missing handler is a surface integration failure.

### 2. Add the server resolver

```ts
// src/lib/construct-runtime/server.ts
import { createConstructNextRuntimeServer } from "@construct/sdk/next/server";

export const constructRuntime = createConstructNextRuntimeServer({
  environment: process.env,
  surfaceId: "todos.main",
});
```

```ts
// src/app/api/construct/runtime-artifacts/resolve/route.ts
import { constructRuntime } from "@/lib/construct-runtime/server";

export const POST = constructRuntime.resolveArtifact;
```

The server adapter authenticates to the Platform API with the configured
runtime target, validates the returned descriptor and identity, and returns
only approved immutable asset URLs. Published modules and styles are served
from the configured runtime asset origin; the host does not proxy private
artifact objects to the browser.

### 3. Add runtime headers

```ts
// next.config.ts
import { constructRuntimeHeadersFromEnv } from "@construct/sdk/next/server";
import type { NextConfig } from "next";

const runtimeHeaders = constructRuntimeHeadersFromEnv(process.env);

const nextConfig: NextConfig = {
  async headers() {
    return runtimeHeaders;
  },
};

export default nextConfig;
```

This adds the configured immutable asset origin to the host CSP and permits the
exact configured Construct control-plane origin to frame the host for setup and
sandbox inspection. Development also retains the script behavior Next.js needs
locally.

### 4. Configure the target

Each running host environment uses one Construct runtime target and these five
environment variables:

```dotenv
CONSTRUCT_CONTROL_PLANE_ORIGIN=https://app-dev.example.com
CONSTRUCT_PLATFORM_API_URL=http://127.0.0.1:4100
CONSTRUCT_RUNTIME_TARGET_ID=<target-id>
CONSTRUCT_RUNTIME_TARGET_SECRET=<target-secret>
CONSTRUCT_RUNTIME_ASSET_ORIGIN=https://assets.example.com
```

- `CONSTRUCT_CONTROL_PLANE_ORIGIN` is the exact Construct app origin allowed to
  embed the host for setup and sandbox inspection.
- `CONSTRUCT_PLATFORM_API_URL` is the Platform API base URL reachable from the
  host server.
- `CONSTRUCT_RUNTIME_TARGET_ID` identifies the development or production target
  for this host environment.
- `CONSTRUCT_RUNTIME_TARGET_SECRET` authenticates that target.
- `CONSTRUCT_RUNTIME_ASSET_ORIGIN` is the exact public origin allowed to serve
  approved immutable runtime modules and styles.

All five variables are consumed by server-side SDK code. The target ID and
secret are credentials; keep them in `.env.local`, Vercel environment
variables, or the equivalent server-side secret store. Never prefix target
credentials with `NEXT_PUBLIC_`, embed them in client source, or return them
from a host route. Construct shows a target secret only when the target is
created or rotated; store the new value at that point.

The target secret is a bearer credential. The configured host origin is
routing and operator metadata, not cryptographic proof of which server is
calling, so copying the credential authorizes the recipient until it is
rotated.

A local host normally uses a development target and a local Platform API URL. A
deployed host normally uses a production target and the public Platform API
URL. The target controls which selector kinds that host may resolve:

- Development target: `?construct-version=<versionId>` resolves that exact
  approved version. With no selector, the host fallback remains active.
- Production target: `?construct=<releaseId>` resolves that exact immutable
  release. With no selector, the target's currently assigned release resolves
  as the production default.

Version and release IDs are UUIDs. Supplying both selector parameters, repeating
one, or supplying an invalid ID is rejected. An exact selector failure is not
silently retried as the production default.

For hosts that capture selection during client instrumentation:

```ts
// src/instrumentation-client.ts
import { captureConstructRuntimeSelection } from "@construct/sdk/next/client";

captureConstructRuntimeSelection({ document, location });
```

Selection is immutable for the lifetime of the document so client navigation
cannot silently switch the mounted runtime.

## Declare host operations

Next route declarations keep product capability contracts beside the host code
that implements them:

```ts
// src/app/api/todos/route.ts
import { defineRouteOperations } from "@construct/sdk/next";
import { z } from "zod";

const todoSchema = z.object({
  id: z.string().uuid().describe("Stable todo identifier"),
  title: z.string().min(1).describe("Short description of the work item"),
  completed: z.boolean().describe("Whether the work is complete"),
});

export const operations = defineRouteOperations({
  GET: {
    kind: "resource",
    id: "todos.list",
    title: "List todos",
    description: "Returns todo items visible to the current user.",
    input: z.object({}),
    output: z.array(todoSchema),
  },
  POST: {
    kind: "action",
    id: "todos.create",
    title: "Create todo",
    description: "Creates a new incomplete todo item.",
    input: z.object({ title: z.string().min(1).max(120) }),
    output: todoSchema,
    invalidates: ["todos.list"],
  },
});
```

Semantic fields are optional. Zod descriptions and constraints improve
operation documentation and later product suggestions, while Gatekeeper
preserves a bounded portable schema without executing the host route module.
Dynamic schema logic outside the supported static subset is reported during
permission compilation.

## Repository authority

```ts
// construct.scope.ts
import { defineConstructScope } from "@construct/sdk";

export default defineConstructScope({
  read: {
    allow: ["src/**", "package.json"],
    deny: [".env*", "node_modules/**", ".next/**"],
  },
  scripts: {
    allow: ["typecheck", "build"],
    review: ["lint"],
    deny: ["dev"],
  },
});
```

These declarations are intentionally thin authoring markers. Gatekeeper scans
the repository and resolves them into authority metadata.

## Runtime trust boundary

The current production loader is `trusted-same-realm`. An approved restricted
React artifact executes as trusted host frontend code; it is not a browser
sandbox. Hosts must approve the exact version or release, authority package,
capability bindings, and audience, retain fallback and revocation, and
authorize every backend operation independently.

## Blueprint consumer packages

External dogfood repositories must consume built packages rather than copied
SDK source. Until registry publication is established, this root command
creates content-addressed consumer archives for the authority manifest,
runtime, and SDK:

```sh
pnpm sdk:pack-consumer -- /absolute/output/directory
```

The output manifest records each archive SHA-256. A consumer may pin these
archives with package-manager overrides; it must not edit or rebuild their
contents.
